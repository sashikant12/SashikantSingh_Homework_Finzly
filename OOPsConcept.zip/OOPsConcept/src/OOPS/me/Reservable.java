package OOPS.me;

public interface Reservable {
    void reverseItem(LibaryItem item);
}
