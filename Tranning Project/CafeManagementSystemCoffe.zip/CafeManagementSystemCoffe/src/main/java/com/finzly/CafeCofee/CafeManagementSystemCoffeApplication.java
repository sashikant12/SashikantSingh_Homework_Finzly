package com.finzly.CafeCofee;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CafeManagementSystemCoffeApplication {

	public static void main(String[] args) {
		SpringApplication.run(CafeManagementSystemCoffeApplication.class, args);
	}

}
