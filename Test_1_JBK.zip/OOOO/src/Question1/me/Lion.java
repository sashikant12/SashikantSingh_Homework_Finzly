package Question1.me;

public class Lion extends Animal {
    @Override
    public void soundMake() {
        System.out.println("RRR");
    }
}
