package Question1.me;

public class Elephant extends Animal {
    @Override
    public void soundMake() {
        System.out.println("EEE");
    }
}
