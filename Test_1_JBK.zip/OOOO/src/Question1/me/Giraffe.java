package Question1.me;

public class Giraffe extends Animal {
    @Override
    public void soundMake() {
        System.out.println("QQQQ");
    }
}
