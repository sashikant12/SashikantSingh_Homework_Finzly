package Question1.me;

public class Zoo {
    public static void main(String[] args) {
        Animal c = new Animal();
        c.soundMake();
        Animal a = new Lion();
        a.soundMake();
        Animal b = new Elephant();
        b.soundMake();
        Animal d = new Giraffe();
        d.soundMake();
    }

}
