package Question1.me;

public class Animal {
    private String name;
    private int age;

    public void soundMake() {
        System.out.println("Sound make by by Animals are");
    }
}
